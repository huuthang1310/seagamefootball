<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package SeaGameFootball
 */

get_header();
?>
<style>

	.s1 {
    border-bottom: 0px solid #e1e1e1;}
    .inner{
    	padding: 10px;
    }
    
  	.backBtn{
    display: inline-block;
    font-size: 15px;
    color: #fff;
    padding: 10px 30px;
    padding-left: 50px;
    font-weight: bold;
    background: url(//cdn.24h.com.vn/images/Forma-1-copy-home.png) no-repeat 20px;
    background-color: #e31010;
}
.page-header {
    padding-bottom: 9px;
    margin: 40px 0 20px;
    border-bottom: 100px solid #fff;
}
@media screen and (max-width: 480px){
				    
}
</style>



	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title" style="text-align: center;"><?php esc_html_e( 'Truy cập của bạn có thể bị lỗi hoặc không tìm thấy nội dung.', 'seagamefootball' ); ?></h1>
					<div class="page-content">
					<div class="s1">
						<div style="width: 100%;">
							<div class="img" style="text-align: center;">
								<img src="https://cdn.24h.com.vn//images/404img_092018.png" alt="">
							</div>
							<div class="inner">
								<div class="head" style="text-align: center;">
								<a href="<?php echo get_site_url() ?>" class="backBtn">Quay lại trang chủ</a>
								</div>
							</div>
							<div class="clear"></div>
						</div>
					</div>

					

					

				</div><!-- .page-content -->
				</header><!-- .page-header -->

				
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->

	

<?php
get_footer();
