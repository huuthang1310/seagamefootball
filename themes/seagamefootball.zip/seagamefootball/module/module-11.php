<div class="col-md-6 col-md-push-6">
    <ul class="footer-links">
        <li><a data-toggle="modal" href="#myModal1">Thông Tin</a></li>
        <li><a data-toggle="modal" href="#myModal2">Góp Ý</a></li>
    </ul>
</div>
<!-- /footer links -->

<!-- footer copyright -->
<div class="col-md-6 col-md-pull-6">
    <div class="footer-copyright">
        <span>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Bản Quyền &copy;<script>
            document.write(new Date().getFullYear());
            </script> Nhóm B - Chuyên đề web 2 <i class="fa fa-heart-o" aria-hidden="true"></i><a>
                TDC
            </a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></span>
    </div>
</div>