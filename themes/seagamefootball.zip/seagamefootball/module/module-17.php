<div class="section">
    <!-- CONTAINER -->
    <div class="container">
        <!-- ROW -->
        <div class="row">
            <!-- Main Column -->
            <div class="col-md-12">
                <!-- section title -->
                <div class="section-title">
                    <h2 class="title">Video Tổng Hợp</h2>
                </div>
                <!-- /section title -->

                <!-- ARTICLE -->
                
                                <article class="article row-article">
                    <div class="article-img">
                        <a href="#">
                            <img src="http://localhost/seagamefootball/wp-content/uploads/2019/10/video-diem-tin-tuc-the-thao-ngay-16-10.jpg" alt="">
                        </a>
                    </div>
                    <div class="article-body">
                        <ul class="article-info">
                            <li class="article-category"><a href="#">Video Bóng Đá</a></li>
                            <li class="article-type"><i class="fa fa-video-camera"></i></li>
                        </ul>
                        <h3 class="article-title"><a href="http://localhost/seagamefootball/video-tin-nong-bong-da-24h-ngay-hom-nay-16-10-2019/">Video: TIN NÓNG bóng đá 24h ngày hôm nay 16/10/2019</a></h3>
                        <ul class="article-meta">
                            <li><i class="fa fa-clock-o"></i> October 16th, 2019</li>
                            <li><i class="fa fa-comments"></i> 0</li>
                        </ul>
                                                <a href="http://localhost/seagamefootball/video-tin-nong-bong-da-24h-ngay-hom-nay-16-10-2019/"><b>Xem thêm</b></a>
                    </div>
                </article>
                                                                <article class="article row-article">
                    <div class="article-img">
                        <a href="#">
                            <img src="http://localhost/seagamefootball/wp-content/uploads/2019/10/van-hau-sieu-to-khong-lo-dien-hai-cung-nam-lun-1m58.jpg" alt="">
                        </a>
                    </div>
                    <div class="article-body">
                        <ul class="article-info">
                            <li class="article-category"><a href="#">Video Bóng Đá</a></li>
                            <li class="article-type"><i class="fa fa-video-camera"></i></li>
                        </ul>
                        <h3 class="article-title"><a href="http://localhost/seagamefootball/video-van-hau-sieu-to-khong-lo-dien-hai-cung-nam-lun-1m58/">VIDEO: Văn Hậu “siêu to khổng lồ” diễn hài cùng nấm lùn 1m58</a></h3>
                        <ul class="article-meta">
                            <li><i class="fa fa-clock-o"></i> October 16th, 2019</li>
                            <li><i class="fa fa-comments"></i> 0</li>
                        </ul>
                                                <a href="http://localhost/seagamefootball/video-van-hau-sieu-to-khong-lo-dien-hai-cung-nam-lun-1m58/"><b>Xem thêm</b></a>
                    </div>
                </article>
                                                                <article class="article row-article">
                    <div class="article-img">
                        <a href="#">
                            <img src="http://localhost/seagamefootball/wp-content/uploads/2019/10/Video-highlight-tran-Thai-Lan-UAE-Suc-ep-vu-bao-thai2-1571144528-752-width660height424.jpg" alt="">
                        </a>
                    </div>
                    <div class="article-body">
                        <ul class="article-info">
                            <li class="article-category"><a href="#">Video Bóng Đá</a></li>
                            <li class="article-type"><i class="fa fa-video-camera"></i></li>
                        </ul>
                        <h3 class="article-title"><a href="http://localhost/seagamefootball/video-highlight-tran-thai-lan-uae-ruot-duoi-nghet-tho-don-troi-giang-dau-hiep-2/">Video highlight trận Thái Lan – UAE: Rượt đuổi nghẹt thở &amp; đòn “trời giáng” đầu hiệp 2</a></h3>
                        <ul class="article-meta">
                            <li><i class="fa fa-clock-o"></i> October 16th, 2019</li>
                            <li><i class="fa fa-comments"></i> 0</li>
                        </ul>
                        (Video bóng đá, kết quả bóng đá Thái Lan – UAE, bảng G vòng loại World Cup 2022 khu vực châu Á) Trận đấu diễn ra căng thẳng cho đến phút bù giờ cuối cùng, nhưng đòn phủ đầu trong hiệp 2 đã ấn định kết quả chung cuộc.                        <a href="http://localhost/seagamefootball/video-highlight-tran-thai-lan-uae-ruot-duoi-nghet-tho-don-troi-giang-dau-hiep-2/"><b>Xem thêm</b></a>
                    </div>
                </article>
                                                                <article class="article row-article">
                    <div class="article-img">
                        <a href="#">
                            <img src="http://localhost/seagamefootball/wp-content/uploads/2019/10/HLANH.jpg" alt="">
                        </a>
                    </div>
                    <div class="article-body">
                        <ul class="article-info">
                            <li class="article-category"><a href="#">Video Bóng Đá</a></li>
                            <li class="article-type"><i class="fa fa-video-camera"></i></li>
                        </ul>
                        <h3 class="article-title"><a href="http://localhost/seagamefootball/ch-czech-2-1-anh/">CH Czech 2-1 Anh</a></h3>
                        <ul class="article-meta">
                            <li><i class="fa fa-clock-o"></i> October 12th, 2019</li>
                            <li><i class="fa fa-comments"></i> 1</li>
                        </ul>
                                                <a href="http://localhost/seagamefootball/ch-czech-2-1-anh/"><b>Xem thêm</b></a>
                    </div>
                </article>
                                                                            </div>

        </div>
        <!-- /ROW -->
    </div>
    <!-- /CONTAINER -->
</div>