<?php $Url = get_template_directory_uri(); ?>
<div class="col-md-4">
    <!-- footer about -->
    <div class="footer-widget about-widget">
        <div class="footer-logo">
            <a href="#" class="logo"><img data-src="<?php echo $Url ?>/img/images1.png" alt=""></a>
            <p>Website cung cấp tin tức bóng đá, lịch thi đấu, xếp hạng, và thông tin liên quan Seagame.
            </p>
        </div>
    </div>
    <!-- /footer about -->

    <!-- footer social -->
    <div class="footer-widget social-widget">
        <div class="widget-title">
            <h3 class="title">Theo Dõi Tại</h3>
        </div>
        <ul>
            <li><a href="#" class="facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" class="google"><i class="fa fa-google"></i></a></li>
            <li><a href="#" class="youtube"><i class="fa fa-youtube"></i></a></li>

        </ul>
    </div>
    <!-- /footer social -->
</div>