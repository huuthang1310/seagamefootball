<?php $Url = get_template_directory_uri(); ?>
<div id="myModal1" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Thông Tin Nhóm</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p>Nhóm B Chuyên Đề Phát Triển Web 2</p>
                                <p> + Bùi Hửu Thắng</p>
                                <p> + Nguyễn Hãi Phúc Khang</p>
                                <p> + Nguyễn Minh Trinh</p>
                                <p> + Đoàn Vũ Quốc Khiêm</p>
                            </div>
                            <div class="col-md-6">
                                <p>Giáo Viên Hướng Dẫn
                                </p>
                                <p>+ Thầy Phan Thanh Nhuần</p>
                                <div class="row">
                                    <div class="col-md-4">
                                        <img style="width : 70px;" class="img-responsive"
                                            data-src="<?php echo $Url ?>/img/Logo-Cao-dang1.jpg">
                                    </div>
                                    <div class="col-md-8">
                                        <p>Trường Cao Đẳng Công Nghệ Thủ Đức</p>
                                        <p>Địa chỉ : 53 Võ Văn Ngân, Linh Chiểu, Thủ Đức, Hồ Chí Minh</p>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>